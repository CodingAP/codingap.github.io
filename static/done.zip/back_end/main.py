from typing import Mapping, Any
import os
from http_daemon import delay_open_url, serve_pages
from datetime import datetime

players: dict[str, tuple[int, int]] = {}
changes: dict[str, dict[str, tuple[int, int, str]]] = {}

def serve_request(params: Mapping[str, Any]) -> Mapping[str, Any]:
    if params['action'] == 'join':
        return join_game(params)
    elif params['action'] == 'update':
        return get_update(params)
    elif params['action'] == 'move':
        return move_player(params)

def join_game(params: Mapping[str, Any]) -> Mapping[str, Any]:
    print(f'join_game was called with {params}')
    players[params['id']] = (100, 100)
    changes[params['id']] = {}
    for id in players:
        if id != params['id']:
            changes[id][params['id']] = (100, 100, "")

    return { 'players': players, 'time': datetime.now().isoformat() }

def get_update(params: Mapping[str, Any]) -> Mapping[str, Any]:
    global changes
    
    old_changes = changes[params['id']].copy()
    changes[params['id']].clear()
    return { 'players': old_changes, 'time': datetime.now().isoformat() }

def move_player(params: Mapping[str, Any]) -> Mapping[str, Any]:
    print(f'move_player was called with {params}')
    players[params['id']] = (params['x'], params['y'])

    for id in players:
        if id != params['id']: 
            changes[id][params['id']] = (params['x'], params['y'], datetime.now().isoformat())

    return {
        'message': 'yo momma',
    }

def main() -> None:
    # Get set up
    os.chdir(os.path.join(os.path.dirname(__file__), '../front_end'))

    # Serve pages
    port = 8987
    delay_open_url(f'http://127.0.0.1:{port}/game.html', .1)
    serve_pages(port, {
        'ajax.html': serve_request
    })

if __name__ == "__main__":
    main()
