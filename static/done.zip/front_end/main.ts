interface OnClickHandler
{
    (x: number, y: number): void;
}

interface HttpPostCallback {
	(x: any): any;
}

interface UpdateHandler
{
    (): void;
}

const sleep = async (ms: number) => {
    return new Promise(resolve => setTimeout(resolve, ms));
}

class Sprite {
    x: number;
    y: number;
    speed: number;
    image: HTMLImageElement;
    dest_x: number;
    dest_y: number;
    bombId: number;
    onclick: OnClickHandler;
    update: UpdateHandler;

	constructor(x: number, y: number, image_url: string, update_method: UpdateHandler, onclick_method: OnClickHandler) {
		this.x = x;
		this.y = y;
        this.speed = 4;
		this.image = new Image();
		this.image.src = image_url;
		this.update = update_method;
		this.onclick = onclick_method;
        this.dest_x = x;
        this.dest_y = y;
        this.bombId = -1;
	}

	set_destination(x: number, y: number) {
		this.dest_x = x;
		this.dest_y = y;
	}

	ignore_click(x: number, y: number) {
	}

	move(dx: number, dy: number) {
		this.dest_x = this.x + dx;
		this.dest_y = this.y + dy;
	}

	go_toward_destination() {
		if(this.dest_x === undefined)
			return;

		let dist_remaining = Math.sqrt((this.dest_x - this.x) * (this.dest_x - this.x) + (this.dest_y - this.y) * (this.dest_y - this.y));
		let step_size = Math.min(this.speed, dist_remaining);
		let angle = Math.atan2(this.dest_y - this.y, this.dest_x - this.x)
		this.x += step_size * Math.cos(angle);
		this.y += step_size * Math.sin(angle);
	}

	sit_still() {
	}
}

class Model {
    sprites: Sprite[];
    my_turtle: Sprite;
	other_turtles: Record<string, Sprite>;
    bombCount: number;

	constructor() {
		this.sprites = [];
		this.sprites.push(new Sprite(200, 100, "lettuce.png", Sprite.prototype.sit_still, Sprite.prototype.ignore_click));
		this.my_turtle = new Sprite(50, 50, "blue_robot.png", Sprite.prototype.go_toward_destination, Sprite.prototype.set_destination);
		this.sprites.push(this.my_turtle);
		this.other_turtles = {};
        this.bombCount = 0;
	}

	update() {
		for (const sprite of this.sprites) {
			sprite.update();
		}
	}

	onclick(x: number, y: number) {
		for (const sprite of this.sprites) {
			sprite.onclick(x, y);
		}
	}

	move(dx: number, dy: number) {
		this.my_turtle.move(dx, dy);
	}

	add_player(id: string, x: number, y: number) {
		let new_turtle = new Sprite(x, y, "green_robot.png", Sprite.prototype.go_toward_destination, Sprite.prototype.sit_still);
		(this.other_turtles as any)[id] = new_turtle;
		this.sprites.push(new_turtle);
	}
}

class View
{
    model: Model;
    canvas: HTMLCanvasElement;

	constructor(model: Model) {
		this.model = model;
		this.canvas = document.getElementById("myCanvas") as HTMLCanvasElement;
	}

	update() {
		let ctx = this.canvas.getContext("2d") as CanvasRenderingContext2D;
		ctx.clearRect(0, 0, 1000, 500);
		for (const sprite of this.model.sprites) {
			ctx.drawImage(sprite.image, sprite.x - sprite.image.width / 2, sprite.y - sprite.image.height);
		}
	}
}

class Controller
{
    key_right: boolean;
    key_left: boolean;
    key_up: boolean;
    key_down: boolean;
    model: Model;
    view: View;

	constructor(model: Model, view: View) {
		this.model = model;
		this.view = view;
		this.key_right = false;
		this.key_left = false;
		this.key_up = false;
		this.key_down = false;
		let self = this;
		view.canvas.addEventListener("click", function(event) { self.onClick(event); });
		document.addEventListener('keydown', function(event) { self.keyDown(event); }, false);
		document.addEventListener('keyup', function(event) { self.keyUp(event); }, false);
	}

	onClick(event: MouseEvent) {
		const x = event.pageX - this.view.canvas.offsetLeft;
		const y = event.pageY - this.view.canvas.offsetTop;
        
        this.model.onclick(x, y);
        fetch('ajax.html', { method: 'post', body: JSON.stringify({ id: g_id, action: 'move', x: x, y: y }) })
            .then(response => response.json())
            .then(this.onAcknowledgeClick);
	}

	keyDown(event: KeyboardEvent) {
		if(event.keyCode == 39) this.key_right = true;
		else if(event.keyCode == 37) this.key_left = true;
		else if(event.keyCode == 38) this.key_up = true;
		else if(event.keyCode == 40) this.key_down = true;
        else if(event.keyCode == 32) this.place_bomb();
	}

	keyUp(event: KeyboardEvent) {
		if(event.keyCode == 39) this.key_right = false;
		else if(event.keyCode == 37) this.key_left = false;
		else if(event.keyCode == 38) this.key_up = false;
		else if(event.keyCode == 40) this.key_down = false;
	}

	update() {
		let dx = 0;
		let dy = 0;
        let speed = this.model.my_turtle.speed;
		if(this.key_right) dx += speed;
		if(this.key_left) dx -= speed;
		if(this.key_up) dy -= speed;
		if(this.key_down) dy += speed;
		if(dx != 0 || dy != 0)
			this.model.move(dx, dy);
	}

    place_bomb() {
        let newBomb = new Sprite(this.model.my_turtle.x, this.model.my_turtle.y, 'bomb.png', Sprite.prototype.sit_still, Sprite.prototype.ignore_click);
        let newExplosion = new Sprite(this.model.my_turtle.x, this.model.my_turtle.y + 30, 'explosion.png', Sprite.prototype.sit_still, Sprite.prototype.ignore_click);
        newBomb.bombId = this.model.bombCount;
        newExplosion.bombId = -2;
        this.model.bombCount++;
        this.model.sprites.push(newBomb);

        let newAudio = new Audio('bomb.mp3');
        sleep(3000).then(() => {
            for (let i = this.model.sprites.length - 1; i >= 0; i--) {
                if (this.model.sprites[i].bombId == newBomb.bombId) {
                    this.model.sprites.splice(i, 1);
                    this.model.sprites.push(newExplosion);

                    newAudio.play();
                }
            }

            sleep(300).then(() => {
                for (let i = this.model.sprites.length - 1; i >= 0; i--) {
                    if (this.model.sprites[i].bombId == -2) {
                        this.model.sprites.splice(i, 1);
                    }
                }
            });
        })
    }

	onAcknowledgeClick(ob: any) {
		console.log(`Response to click: ${JSON.stringify(ob)}`);
	}
}

class Game {
    model: Model;
    view: View;
    controller: Controller;
	last_updates_request_time: number;

	constructor() {
		this.model = new Model();
		this.view = new View(this.model);
		this.controller = new Controller(this.model, this.view);
		this.last_updates_request_time = Date.now();
	}

	onTimer() {
		this.controller.update();
		this.model.update();
		this.view.update();

		const time = Date.now();
		if (time - this.last_updates_request_time >= 1000) {
			this.last_updates_request_time = time;
            fetch('ajax.html', { method: 'post', body: JSON.stringify({ id: g_id, action: 'update' }) })
                .then(response => response.json())
                .then(json => {
                    Object.keys(json.players).forEach(id => {
                        if (id == g_id) return;

                        let backend_time = new Date(json.players[id][2]).getTime();
                        let time_skew = new Date().getTime() - backend_time;

                        if (this.model.other_turtles[id] == null) this.model.add_player(id, json.players[id][0], json.players[id][1]);
                        else {
                            this.model.other_turtles[id].dest_x = json.players[id][0];
                            this.model.other_turtles[id].dest_y = json.players[id][1];
                        }

                        let distance = Math.sqrt(Math.pow(this.model.other_turtles[id].dest_x - this.model.other_turtles[id].x, 2) + Math.pow(this.model.other_turtles[id].dest_y - this.model.other_turtles[id].y, 2))
                        let timeToTravel = distance / 5;
                        console.log(distance, timeToTravel, time_skew);

                        this.model.other_turtles[id].speed = distance / ((timeToTravel - (time_skew / 40)));
                    });
                });
		}
	}
}

const random_id = (len:number) => {
    let p = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    return [...Array(len)].reduce(a => a + p[Math.floor(Math.random() * p.length)], '');
}

const g_origin = new URL(window.location.href).origin;
const g_id = random_id(12);

let game = new Game();
let timer = setInterval(() => { game.onTimer(); }, 40);
window.onload = async () => {
    const response = await fetch('ajax.html', { method: 'post', body: JSON.stringify({ id: g_id, action: 'join' }) })
    const json = await response.json();
    
    Object.keys(json.players).forEach(id => {
        if (id == g_id) return;

        game.model.add_player(id, json.players[id][0], json.players[id][1]);
    });
}